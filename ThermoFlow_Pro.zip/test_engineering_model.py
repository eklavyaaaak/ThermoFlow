import unittest
from engineering_model import *

class ModelTests(unittest.TestCase):
    def setUp(self):
        self.cool=Coolant()
        self.pipe=Pipe()
        self.pump=PumpCurve()
    def test_operating_point_positive_and_balanced(self):
        op=solve_operating_point(self.cool,self.pipe,self.pump)
        self.assertGreater(op["flow_m3h"],0)
        self.assertAlmostEqual(op["pump_head_m"],op["system_head_m"],places=5)
        self.assertGreater(op["electrical_power_w"],op["hydraulic_power_w"])
    def test_pressure_drop_increases_with_flow(self):
        low=hydraulic_state(3,self.cool,self.pipe)["total_dp_pa"]
        high=hydraulic_state(6,self.cool,self.pipe)["total_dp_pa"]
        self.assertGreater(high,low)
    def test_hx_energy_balance(self):
        hx=HXInputs()
        r=heat_exchanger(hx)
        qh=hx.hot_mass_flow_kg_s*4180*(hx.hot_in_c-r["hot_out_c"])/1000
        qc=hx.cold_mass_flow_kg_s*4180*(r["cold_out_c"]-hx.cold_in_c)/1000
        self.assertAlmostEqual(qh,qc,places=8)
        self.assertGreater(r["duty_kw"],0)
    def test_ua_inverse(self):
        hx=HXInputs()
        target=heat_exchanger(hx)["duty_kw"]*0.7
        ua=required_ua_for_duty(target,hx)["required_ua_kw_k"]
        hx2=HXInputs(ua_kw_k=ua)
        self.assertAlmostEqual(heat_exchanger(hx2)["duty_kw"],target,places=5)

if __name__=="__main__": unittest.main()
